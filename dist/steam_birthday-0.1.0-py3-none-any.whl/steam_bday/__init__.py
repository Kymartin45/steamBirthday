"""
steamBirthday

Get your Steam accounts birthday
"""

__verison__ = '0.1.0'
__author__ = 'Kyle Martin'
__url__ = 'https://github.com/Kymartin45/steamBirthday'
